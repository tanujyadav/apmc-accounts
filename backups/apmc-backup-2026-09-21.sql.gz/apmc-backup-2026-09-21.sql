--
-- PostgreSQL database dump
--

\restrict g7Ol7CXHahjJxlGparhc1A0sFwcCS51CBGg0yaNjyZWtSOtX7jHUadpRXhYy41b

-- Dumped from database version 18.6 (6569466)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: apmc_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.apmc_profile (
    id integer NOT NULL,
    mandi_name text NOT NULL,
    mandi_name_hindi text,
    address text,
    district text,
    state text DEFAULT 'Uttar Pradesh'::text NOT NULL,
    pincode text,
    phone text,
    email text,
    gstin text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: apmc_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.apmc_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: apmc_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.apmc_profile_id_seq OWNED BY public.apmc_profile.id;


--
-- Name: app_security_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_security_settings (
    id integer NOT NULL,
    pin_hash text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: app_security_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_security_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_security_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_security_settings_id_seq OWNED BY public.app_security_settings.id;


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_accounts (
    id integer NOT NULL,
    bank_name text NOT NULL,
    branch text NOT NULL,
    account_number text NOT NULL,
    ifsc_code text NOT NULL,
    account_type text NOT NULL,
    opening_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    opening_balance_date date,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_accounts_id_seq OWNED BY public.bank_accounts.id;


--
-- Name: bill_number_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bill_number_counters (
    financial_year text NOT NULL,
    last_serial integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bills (
    id integer NOT NULL,
    bill_no text NOT NULL,
    bill_date date NOT NULL,
    vendor_name text NOT NULL,
    description text NOT NULL,
    ledger_head_id integer NOT NULL,
    financial_year text NOT NULL,
    amount numeric(14,2) NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    payment_date date,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    sub_voucher_no text,
    authority_details text,
    cheque_details text,
    payment_mode text DEFAULT 'bank'::text NOT NULL,
    bank_account_id integer,
    cheque_no text,
    cheque_date date,
    deduction_cheque_no text,
    deduction_cheque_date date,
    posted_cashbook_entry_id integer,
    deduction_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bills_id_seq OWNED BY public.bills.id;


--
-- Name: brs_statements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brs_statements (
    id integer NOT NULL,
    bank_account_id integer,
    statement_month text NOT NULL,
    bank_interest numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    indirect_deposits numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    other_receipts numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    bank_charges numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    other_expenses numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    passbook_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    remarks text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    cashbook_balance_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    unpresented_cheques_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    unpresented_count_snapshot integer DEFAULT 0 NOT NULL,
    uncleared_deposits_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    uncleared_count_snapshot integer DEFAULT 0 NOT NULL,
    total_additions_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    balance_after_additions_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_deductions_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    calculated_balance_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    difference_snapshot numeric(14,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: brs_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.brs_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: brs_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.brs_statements_id_seq OWNED BY public.brs_statements.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id integer NOT NULL,
    financial_year text NOT NULL,
    ledger_head_id integer NOT NULL,
    allocated_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    main_budget numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    supplementary_budget numeric(14,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: cash_deposit_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_deposit_allocations (
    id integer NOT NULL,
    cash_deposit_id integer NOT NULL,
    cashbook_entry_id integer,
    allocated_amount numeric(14,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    cashbook_opening_balance_id integer
);


--
-- Name: cash_deposit_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_deposit_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cash_deposit_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_deposit_allocations_id_seq OWNED BY public.cash_deposit_allocations.id;


--
-- Name: cash_deposits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_deposits (
    id integer NOT NULL,
    deposit_date date NOT NULL,
    bank_account_id integer NOT NULL,
    slip_no text NOT NULL,
    amount numeric(14,2) NOT NULL,
    deposited_by text NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: cash_deposits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_deposits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cash_deposits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_deposits_id_seq OWNED BY public.cash_deposits.id;


--
-- Name: cashbook_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cashbook_entries (
    id integer NOT NULL,
    entry_date date NOT NULL,
    voucher_no text NOT NULL,
    entry_type text NOT NULL,
    mode text NOT NULL,
    ledger_head_id integer NOT NULL,
    bank_account_id integer,
    cheque_no text,
    party_name text,
    particulars text NOT NULL,
    amount numeric(14,2) NOT NULL,
    reconciled boolean DEFAULT false NOT NULL,
    reconciled_date date,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: cashbook_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cashbook_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cashbook_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cashbook_entries_id_seq OWNED BY public.cashbook_entries.id;


--
-- Name: cashbook_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cashbook_opening_balances (
    id integer NOT NULL,
    financial_year text NOT NULL,
    opening_date date,
    opening_cash numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    opening_bank numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    remarks text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: cashbook_opening_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cashbook_opening_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cashbook_opening_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cashbook_opening_balances_id_seq OWNED BY public.cashbook_opening_balances.id;


--
-- Name: cheques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheques (
    id integer NOT NULL,
    cheque_no text NOT NULL,
    cheque_date date NOT NULL,
    bank_account_id integer NOT NULL,
    party_name text NOT NULL,
    amount numeric(14,2) NOT NULL,
    direction text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    cleared_date date,
    source_bill_id integer
);


--
-- Name: cheques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cheques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cheques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cheques_id_seq OWNED BY public.cheques.id;


--
-- Name: ledger_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger_heads (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    name_hindi text,
    type text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ledger_heads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ledger_heads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ledger_heads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ledger_heads_id_seq OWNED BY public.ledger_heads.id;


--
-- Name: parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parties (
    id integer NOT NULL,
    name text NOT NULL,
    name_hindi text,
    party_type text DEFAULT 'trader'::text NOT NULL,
    contact_person text,
    phone text,
    email text,
    address text,
    gstin text,
    license_no text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: parties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parties_id_seq OWNED BY public.parties.id;


--
-- Name: revenue_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revenue_targets (
    id integer NOT NULL,
    financial_year text NOT NULL,
    ledger_head_id integer NOT NULL,
    target_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: revenue_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.revenue_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: revenue_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.revenue_targets_id_seq OWNED BY public.revenue_targets.id;


--
-- Name: shop_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_collections (
    id integer NOT NULL,
    shop_id integer NOT NULL,
    demand_month text NOT NULL,
    receipt_date date,
    receipt_no text,
    rent_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    premium_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    penalty_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_paid numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    payment_mode text DEFAULT 'cash'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_collections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shop_collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shop_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shop_collections_id_seq OWNED BY public.shop_collections.id;


--
-- Name: shops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shops (
    id integer NOT NULL,
    shop_number text NOT NULL,
    block text,
    property_type text DEFAULT 'shop'::text NOT NULL,
    occupant_name text NOT NULL,
    mobile text,
    agreement_start date,
    agreement_end date,
    monthly_rent numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    premium_total numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: shops_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shops_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shops_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shops_id_seq OWNED BY public.shops.id;


--
-- Name: staff_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_members (
    id integer NOT NULL,
    employee_code text NOT NULL,
    name text NOT NULL,
    name_hindi text,
    designation text NOT NULL,
    employment_type text DEFAULT 'regular'::text NOT NULL,
    pan text,
    bank_account text,
    basic_pay numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: staff_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_members_id_seq OWNED BY public.staff_members.id;


--
-- Name: staff_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_payments (
    id integer NOT NULL,
    staff_id integer NOT NULL,
    payment_month text NOT NULL,
    payment_date date,
    payment_type text DEFAULT 'salary'::text NOT NULL,
    basic_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    allowance_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    deduction_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    tds_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    voucher_no text,
    status text DEFAULT 'pending'::text NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: staff_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_payments_id_seq OWNED BY public.staff_payments.id;


--
-- Name: tds_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tds_returns (
    id integer NOT NULL,
    financial_year text NOT NULL,
    quarter text NOT NULL,
    form_type text DEFAULT '24Q'::text NOT NULL,
    section text NOT NULL,
    challan_no text,
    bsr_code text,
    deposit_date date,
    taxable_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    tds_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    interest_late_fee numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    filing_date date,
    acknowledgement_no text,
    status text DEFAULT 'pending'::text NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tds_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tds_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tds_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tds_returns_id_seq OWNED BY public.tds_returns.id;


--
-- Name: apmc_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apmc_profile ALTER COLUMN id SET DEFAULT nextval('public.apmc_profile_id_seq'::regclass);


--
-- Name: app_security_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_security_settings ALTER COLUMN id SET DEFAULT nextval('public.app_security_settings_id_seq'::regclass);


--
-- Name: bank_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts ALTER COLUMN id SET DEFAULT nextval('public.bank_accounts_id_seq'::regclass);


--
-- Name: bills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bills ALTER COLUMN id SET DEFAULT nextval('public.bills_id_seq'::regclass);


--
-- Name: brs_statements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brs_statements ALTER COLUMN id SET DEFAULT nextval('public.brs_statements_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: cash_deposit_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposit_allocations ALTER COLUMN id SET DEFAULT nextval('public.cash_deposit_allocations_id_seq'::regclass);


--
-- Name: cash_deposits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposits ALTER COLUMN id SET DEFAULT nextval('public.cash_deposits_id_seq'::regclass);


--
-- Name: cashbook_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_entries ALTER COLUMN id SET DEFAULT nextval('public.cashbook_entries_id_seq'::regclass);


--
-- Name: cashbook_opening_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_opening_balances ALTER COLUMN id SET DEFAULT nextval('public.cashbook_opening_balances_id_seq'::regclass);


--
-- Name: cheques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheques ALTER COLUMN id SET DEFAULT nextval('public.cheques_id_seq'::regclass);


--
-- Name: ledger_heads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_heads ALTER COLUMN id SET DEFAULT nextval('public.ledger_heads_id_seq'::regclass);


--
-- Name: parties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parties ALTER COLUMN id SET DEFAULT nextval('public.parties_id_seq'::regclass);


--
-- Name: revenue_targets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenue_targets ALTER COLUMN id SET DEFAULT nextval('public.revenue_targets_id_seq'::regclass);


--
-- Name: shop_collections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_collections ALTER COLUMN id SET DEFAULT nextval('public.shop_collections_id_seq'::regclass);


--
-- Name: shops id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shops ALTER COLUMN id SET DEFAULT nextval('public.shops_id_seq'::regclass);


--
-- Name: staff_members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_members ALTER COLUMN id SET DEFAULT nextval('public.staff_members_id_seq'::regclass);


--
-- Name: staff_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_payments ALTER COLUMN id SET DEFAULT nextval('public.staff_payments_id_seq'::regclass);


--
-- Name: tds_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tds_returns ALTER COLUMN id SET DEFAULT nextval('public.tds_returns_id_seq'::regclass);


--
-- Data for Name: apmc_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.apmc_profile (id, mandi_name, mandi_name_hindi, address, district, state, pincode, phone, email, gstin, updated_at) FROM stdin;
\.


--
-- Data for Name: app_security_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_security_settings (id, pin_hash, updated_at) FROM stdin;
1	936d1dafd8b1b6e7fe061b0e0bd5cf8778264d79ac315607734ca41a8fb48b48	2026-09-16 11:15:38.485
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_accounts (id, bank_name, branch, account_number, ifsc_code, account_type, opening_balance, opening_balance_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: bill_number_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bill_number_counters (financial_year, last_serial, updated_at) FROM stdin;
\.


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bills (id, bill_no, bill_date, vendor_name, description, ledger_head_id, financial_year, amount, status, payment_date, created_at, sub_voucher_no, authority_details, cheque_details, payment_mode, bank_account_id, cheque_no, cheque_date, deduction_cheque_no, deduction_cheque_date, posted_cashbook_entry_id, deduction_amount, net_amount) FROM stdin;
\.


--
-- Data for Name: brs_statements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brs_statements (id, bank_account_id, statement_month, bank_interest, indirect_deposits, other_receipts, bank_charges, other_expenses, passbook_balance, remarks, updated_at, cashbook_balance_snapshot, unpresented_cheques_snapshot, unpresented_count_snapshot, uncleared_deposits_snapshot, uncleared_count_snapshot, total_additions_snapshot, balance_after_additions_snapshot, total_deductions_snapshot, calculated_balance_snapshot, difference_snapshot) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, financial_year, ledger_head_id, allocated_amount, remarks, created_at, main_budget, supplementary_budget) FROM stdin;
\.


--
-- Data for Name: cash_deposit_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_deposit_allocations (id, cash_deposit_id, cashbook_entry_id, allocated_amount, created_at, cashbook_opening_balance_id) FROM stdin;
\.


--
-- Data for Name: cash_deposits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_deposits (id, deposit_date, bank_account_id, slip_no, amount, deposited_by, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: cashbook_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cashbook_entries (id, entry_date, voucher_no, entry_type, mode, ledger_head_id, bank_account_id, cheque_no, party_name, particulars, amount, reconciled, reconciled_date, created_at) FROM stdin;
\.


--
-- Data for Name: cashbook_opening_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cashbook_opening_balances (id, financial_year, opening_date, opening_cash, opening_bank, remarks, updated_at) FROM stdin;
\.


--
-- Data for Name: cheques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheques (id, cheque_no, cheque_date, bank_account_id, party_name, amount, direction, status, remarks, created_at, cleared_date, source_bill_id) FROM stdin;
\.


--
-- Data for Name: ledger_heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger_heads (id, code, name, name_hindi, type, created_at) FROM stdin;
1	1-A	Mandi Fee	मण्डी शुल्क	income	2026-09-08 04:43:43.76385
2	1-B	Development Cess	विकास सेस	income	2026-09-08 04:43:43.76385
3	2	License Fee	लाइसेंस शुल्क	income	2026-09-08 04:43:43.76385
7	4	Interest on Invested Funds	विनियोजित धन पर ब्याज	income	2026-09-08 04:43:43.76385
5	6-B	Building / Shop Rent / Surcharge	भवन/दुकान का किराया/अधिभार	income	2026-09-08 04:43:43.76385
15	3	Sale of Forms etc.	प्रपत्र आदि की बिक्री	income	2026-09-08 08:00:21.863594
16	5-A	Receipts from Parishad / Government	परिषद/शासन से	income	2026-09-08 08:00:21.863594
17	5-B	Receipts from Banks	बैंकों से	income	2026-09-08 08:00:21.863594
18	5-C	Receipts from Mandi Samitis	मण्डी समितियों से	income	2026-09-08 08:00:21.863594
19	5-D	Loan Repayment (from Mandi Samitis)	ऋण की वापसी (मण्डी समितियों से)	income	2026-09-08 08:00:21.863594
20	5-E	GST	GST	income	2026-09-08 08:00:21.863594
21	5-F	Refund of Land Compensation (if any)	भूमि के प्रतिकर की वापसी (यदि हो)	income	2026-09-08 08:00:21.863594
22	5-G	Funds Released by Parishad for Various Schemes	विभिन्न योजनाओं के लिये परिषद से अवमुक्त धनराशि	income	2026-09-08 08:00:21.863594
23	5-H	Funds Released by Parishad for Land Purchase / Compensation Payment	भूमि क्रय/प्रतिकर अदायगी हेतु परिषद से अवमुक्त धनराशि	income	2026-09-08 08:00:21.863594
24	5-I	Any Other Loan / Grant or Loan Repayment (if any)	अन्य कोई ऋण/अनुदान या ऋण की वापसी (यदि हो)	income	2026-09-08 08:00:21.863594
25	5-J	Security Deposit / Guarantee	जमानत धनराशि/प्रतिभूति	income	2026-09-08 08:00:21.863594
26	5-L	TDS Recovery / Income Tax Refund / Electricity Recovery	T.D.S. वसूली/आयकर की वापसी/विद्युत वसूली	income	2026-09-08 08:00:21.863594
27	5-M	Interim Amount Received Back from Paddy and Wheat Procurement	धान एवं गेहूं खरीद से अन्तरिम वापस प्राप्त धनराशि	income	2026-09-08 08:00:21.863594
28	6-A	Loan Repayment (from Employees)	ऋण की वापसी (कर्मचारियों से)	income	2026-09-08 08:00:21.863594
29	6-C	Sale / Premium of Shop / Land	दुकान/भूमि की बिक्री/प्रीमियम	income	2026-09-08 08:00:21.863594
30	6-D	Compounding Fee	शमन शुल्क	income	2026-09-08 08:00:21.863594
31	6-E	Interest on Outstanding Mandi Fee	बकाया मण्डी शुल्क पर ब्याज	income	2026-09-08 08:00:21.863594
32	6-F	User Charge (Non-Specified Agricultural Produce)	यूजर चार्ज (गैर निर्दिष्ट कृषि उत्पाद)	income	2026-09-08 08:00:21.863594
33	6-G	Interest on Outstanding User Charge	बकाया यूजर चार्ज पर ब्याज	income	2026-09-08 08:00:21.863594
34	6-H	Interest Amount (Building / Shop / Canteen / Premium)	ब्याज की धनराशि (भवन/दुकान/कैंटीन/प्रीमियम)	income	2026-09-08 08:00:21.863594
35	6-I	Residential Rent / Godown Rent (GST Exempt)	आवास किराया/गोदाम किराया (जी०एस०टी० मुक्त)	income	2026-09-08 08:00:21.863594
36	6-J	Registration Fee / Transfer Fee	पंजीकरण शुल्क/अन्तरण शुल्क	income	2026-09-08 08:00:21.863594
37	6-K	Administrative Fee Received under MSP Procurement	MSP पर खरीद के अन्तर्गत प्राप्त प्रशासनिक शुल्क	income	2026-09-08 08:00:21.863594
38	6-L	Other Income	अन्य	income	2026-09-08 08:00:21.863594
39	EXP-01	Establishment Expenses	अधिष्ठान व्यय	expense	2026-09-08 08:49:42.726946
40	EXP-02	Cleaning Arrangement Expenses (Mandi Site)	सफाई व्यवस्था व्यय (मंडी स्थल)	expense	2026-09-08 08:49:42.726946
41	EXP-03	Electricity Arrangement Expenses (Mandi Site)	विद्युत व्यवस्था व्यय (मंडी स्थल)	expense	2026-09-08 08:49:42.726946
42	EXP-04	Security Arrangement Expenses (Mandi Site)	सुरक्षा व्यवस्था व्यय (मंडी स्थल)	expense	2026-09-08 08:49:42.726946
43	EXP-05	Office Stationery / Printing Expenses	कार्यालय स्टेशनरी/प्रिंटिंग व्यय	expense	2026-09-08 08:49:42.726946
44	EXP-06	Court / Legal Expenses	न्यायालय व्यय	expense	2026-09-08 08:49:42.726946
45	EXP-07	Establishment Expenses (Out Source)	अधिष्ठान व्यय (Out Source)	expense	2026-09-08 08:49:42.726946
46	EXP-08	GST Payment Expenses	GST भुगतान व्यय	expense	2026-09-08 08:49:42.726946
47	EXP-09	Purchase of Office Furniture and Equipment	कार्यालय फर्नीचर एवं उपकरण क्रय	expense	2026-09-08 08:49:42.726946
48	EXP-10	Mandi Site Generator Diesel, Repair, Maintenance and Operation Expenses	मंडी स्थल जनरेटर डीजल, मरम्मत, अनुरक्षण एवं संचालन व्यय	expense	2026-09-08 08:49:42.726946
49	EXP-11	Mobile Squad Vehicle and Diesel Payment	सचल दल वाहन & डीजल भुगतान	expense	2026-09-08 08:49:42.726946
50	EXP-12	Office Furniture and Equipment Repair	कार्यालय फर्नीचर उपकरण मरम्मत	expense	2026-09-08 08:49:42.726946
51	EXP-13	Post and Telegraph Expenses	डाक तार व्यय	expense	2026-09-08 08:49:42.726946
52	EXP-14	Medical Reimbursement Expenses	चिकित्सा प्रतिपूर्ति व्यय	expense	2026-09-08 08:49:42.726946
53	EXP-15	Telephone / Broadband / Internet	टेलीफोन/ब्रॉडबैंड/इंटरनेट	expense	2026-09-08 08:49:42.726946
54	EXP-16	Hospitality Expenses	अतिथि सत्कार व्यय	expense	2026-09-08 08:49:42.726946
55	EXP-17	Advertising, Publicity and Promotion	विज्ञापन प्रचार प्रसार	expense	2026-09-08 08:49:42.726946
56	EXP-18	Miscellaneous Expenses	विविध व्यय	expense	2026-09-08 08:49:42.726946
57	EXP-19	Employee Loan Advance (for House / Vehicle)	कर्मचारी ऋण अग्रिम (भवन/वाहन हेतु)	expense	2026-09-08 08:49:42.726946
58	EXP-20	Stamping of Electronic Weighing Scales	इलेक्ट्रॉनिक कांटो के मुद्रांकन	expense	2026-09-08 08:49:42.726946
59	EXP-21	Other Facility Adjustment (Book Transfer)	अन्य सुविधा समायोजन (बुक ट्रान्सफर)	expense	2026-09-08 08:49:42.726946
60	EXP-22	Drinking Water Arrangement	पेयजल व्यवस्था	expense	2026-09-08 08:49:42.726946
61	EXP-23	Lighting Arrangement	प्रकाश व्यवस्था	expense	2026-09-08 08:49:42.726946
62	EXP-24	Computer Repair / Maintenance (Including All Expenses)	कम्प्यूटरों की मरम्मत/अनुरक्षण (समस्त व्यय सहित)	expense	2026-09-08 08:49:42.726946
63	EXP-25	Farmer Personal Accident Assistance Scheme	कृषक व्यक्तिगत दुर्घटना सहायता योजना	expense	2026-09-08 08:49:42.726946
64	EXP-26	Farmer Farm and Threshing Floor Fire Accident Assistance Scheme	कृषक खेत खलिहान अग्निकाण्ड दुर्घटना सहायता योजना	expense	2026-09-08 08:49:42.726946
65	EXP-27	Balance Sheet / Other Work C.A. Fees	बैलेंस शीट/अन्य कार्य C.A. फीस	expense	2026-09-08 08:49:42.726946
66	EXP-28	Cash-in-Safe and Cash-in-Transit Insurance Expenses	कैश इन सेफ तथा कैश इन ट्रांजिट बीमा व्यय	expense	2026-09-08 08:49:42.726946
67	EXP-29	C.A. Bill	C.A. BILL	expense	2026-09-08 08:49:42.726946
68	EXP-30	Repair of Electronic Weighing Scales and Dusters etc.	इलेक्ट्रॉनिक कांटों व डस्टर इत्यादि की मरम्मत	expense	2026-09-08 08:49:42.726946
69	EXP-31	e-NAM Arrangement	e-NAM व्यवस्था	expense	2026-09-08 08:49:42.726946
70	EXP-32	Travel Allowance	यात्रा भत्ता	expense	2026-09-08 08:49:42.726946
71	EXP-33	CCTV Repair and Maintenance Expenses (Mandi Site)	CCTV मरम्मत व अनुरक्षण व्यय (मंडी स्थल)	expense	2026-09-08 08:49:42.726946
72	EXP-34	Minor / Miscellaneous Repairs	छुट पुट मरम्मत	expense	2026-09-08 08:49:42.726946
74	EXP-36	Funds automatically withdrawn from committee accounts by the Mandi Board (CESS)	मण्डी परिषद् द्वारा समिति खातों से स्वतः निकाली धनराशि (विकास सेस)	expense	2026-09-13 16:57:53.587705
73	EXP-35	Funds automatically withdrawn from committee accounts by the Mandi Board (Market Fee)	मण्डी परिषद् द्वारा समिति खातों से स्वतः निकाली धनराशि (मंडी शुल्क)	expense	2026-09-13 16:55:58.283356
75	7	Fund Auto Credit from Mandi Borad in Mandi Bank A/C (Anudan)	मण्डी परिषद् से समिति खाते में प्राप्त राशि (अनुदान)	income	2026-09-13 17:01:17.621021
\.


--
-- Data for Name: parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parties (id, name, name_hindi, party_type, contact_person, phone, email, address, gstin, license_no, status, created_at) FROM stdin;
\.


--
-- Data for Name: revenue_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.revenue_targets (id, financial_year, ledger_head_id, target_amount, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: shop_collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_collections (id, shop_id, demand_month, receipt_date, receipt_no, rent_amount, premium_amount, penalty_amount, amount_paid, payment_mode, status, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shops (id, shop_number, block, property_type, occupant_name, mobile, agreement_start, agreement_end, monthly_rent, premium_total, status, created_at) FROM stdin;
\.


--
-- Data for Name: staff_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_members (id, employee_code, name, name_hindi, designation, employment_type, pan, bank_account, basic_pay, status, created_at) FROM stdin;
\.


--
-- Data for Name: staff_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_payments (id, staff_id, payment_month, payment_date, payment_type, basic_amount, allowance_amount, deduction_amount, tds_amount, net_amount, voucher_no, status, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: tds_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tds_returns (id, financial_year, quarter, form_type, section, challan_no, bsr_code, deposit_date, taxable_amount, tds_amount, interest_late_fee, filing_date, acknowledgement_no, status, remarks, created_at) FROM stdin;
\.


--
-- Name: apmc_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.apmc_profile_id_seq', 1, false);


--
-- Name: app_security_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_security_settings_id_seq', 1, true);


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_accounts_id_seq', 1, false);


--
-- Name: bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bills_id_seq', 1, false);


--
-- Name: brs_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.brs_statements_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: cash_deposit_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_deposit_allocations_id_seq', 1, false);


--
-- Name: cash_deposits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_deposits_id_seq', 1, false);


--
-- Name: cashbook_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cashbook_entries_id_seq', 1, false);


--
-- Name: cashbook_opening_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cashbook_opening_balances_id_seq', 1, false);


--
-- Name: cheques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cheques_id_seq', 1, false);


--
-- Name: ledger_heads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ledger_heads_id_seq', 75, true);


--
-- Name: parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parties_id_seq', 1, false);


--
-- Name: revenue_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.revenue_targets_id_seq', 1, false);


--
-- Name: shop_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_collections_id_seq', 1, false);


--
-- Name: shops_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shops_id_seq', 1, false);


--
-- Name: staff_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_members_id_seq', 1, false);


--
-- Name: staff_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_payments_id_seq', 1, false);


--
-- Name: tds_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tds_returns_id_seq', 1, false);


--
-- Name: apmc_profile apmc_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apmc_profile
    ADD CONSTRAINT apmc_profile_pkey PRIMARY KEY (id);


--
-- Name: app_security_settings app_security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_security_settings
    ADD CONSTRAINT app_security_settings_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: bill_number_counters bill_number_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_number_counters
    ADD CONSTRAINT bill_number_counters_pkey PRIMARY KEY (financial_year);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: brs_statements brs_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brs_statements
    ADD CONSTRAINT brs_statements_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: cash_deposit_allocations cash_deposit_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposit_allocations
    ADD CONSTRAINT cash_deposit_allocations_pkey PRIMARY KEY (id);


--
-- Name: cash_deposits cash_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposits
    ADD CONSTRAINT cash_deposits_pkey PRIMARY KEY (id);


--
-- Name: cashbook_entries cashbook_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_entries
    ADD CONSTRAINT cashbook_entries_pkey PRIMARY KEY (id);


--
-- Name: cashbook_opening_balances cashbook_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_opening_balances
    ADD CONSTRAINT cashbook_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: cheques cheques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheques
    ADD CONSTRAINT cheques_pkey PRIMARY KEY (id);


--
-- Name: ledger_heads ledger_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_heads
    ADD CONSTRAINT ledger_heads_pkey PRIMARY KEY (id);


--
-- Name: parties parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parties
    ADD CONSTRAINT parties_pkey PRIMARY KEY (id);


--
-- Name: revenue_targets revenue_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenue_targets
    ADD CONSTRAINT revenue_targets_pkey PRIMARY KEY (id);


--
-- Name: shop_collections shop_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_collections
    ADD CONSTRAINT shop_collections_pkey PRIMARY KEY (id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- Name: staff_members staff_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_members
    ADD CONSTRAINT staff_members_pkey PRIMARY KEY (id);


--
-- Name: staff_payments staff_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_pkey PRIMARY KEY (id);


--
-- Name: tds_returns tds_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tds_returns
    ADD CONSTRAINT tds_returns_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts_number_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bank_accounts_number_uidx ON public.bank_accounts USING btree (account_number);


--
-- Name: bank_accounts_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_accounts_status_idx ON public.bank_accounts USING btree (status);


--
-- Name: bills_bank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bills_bank_idx ON public.bills USING btree (bank_account_id);


--
-- Name: bills_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bills_date_idx ON public.bills USING btree (bill_date);


--
-- Name: bills_fy_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bills_fy_status_idx ON public.bills USING btree (financial_year, status);


--
-- Name: bills_head_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bills_head_idx ON public.bills USING btree (ledger_head_id);


--
-- Name: bills_number_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bills_number_uidx ON public.bills USING btree (bill_no);


--
-- Name: bills_posted_cashbook_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bills_posted_cashbook_idx ON public.bills USING btree (posted_cashbook_entry_id);


--
-- Name: brs_month_bank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brs_month_bank_idx ON public.brs_statements USING btree (statement_month, bank_account_id);


--
-- Name: budgets_fy_head_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budgets_fy_head_uidx ON public.budgets USING btree (financial_year, ledger_head_id);


--
-- Name: cash_deposits_bank_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_deposits_bank_date_idx ON public.cash_deposits USING btree (bank_account_id, deposit_date);


--
-- Name: cash_deposits_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_deposits_date_idx ON public.cash_deposits USING btree (deposit_date);


--
-- Name: cash_deposits_slip_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cash_deposits_slip_uidx ON public.cash_deposits USING btree (slip_no);


--
-- Name: cashbook_bank_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cashbook_bank_date_idx ON public.cashbook_entries USING btree (bank_account_id, entry_date);


--
-- Name: cashbook_entry_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cashbook_entry_date_idx ON public.cashbook_entries USING btree (entry_date);


--
-- Name: cashbook_head_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cashbook_head_date_idx ON public.cashbook_entries USING btree (ledger_head_id, entry_date);


--
-- Name: cashbook_opening_fy_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cashbook_opening_fy_uidx ON public.cashbook_opening_balances USING btree (financial_year);


--
-- Name: cashbook_party_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cashbook_party_date_idx ON public.cashbook_entries USING btree (party_name, entry_date);


--
-- Name: cashbook_type_mode_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cashbook_type_mode_date_idx ON public.cashbook_entries USING btree (entry_type, mode, entry_date);


--
-- Name: cheques_bank_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cheques_bank_date_idx ON public.cheques USING btree (bank_account_id, cheque_date);


--
-- Name: cheques_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cheques_date_idx ON public.cheques USING btree (cheque_date);


--
-- Name: cheques_source_bill_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cheques_source_bill_idx ON public.cheques USING btree (source_bill_id);


--
-- Name: cheques_status_direction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cheques_status_direction_idx ON public.cheques USING btree (status, direction);


--
-- Name: deposit_alloc_deposit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_alloc_deposit_idx ON public.cash_deposit_allocations USING btree (cash_deposit_id);


--
-- Name: deposit_alloc_entry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_alloc_entry_idx ON public.cash_deposit_allocations USING btree (cashbook_entry_id);


--
-- Name: deposit_alloc_opening_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_alloc_opening_idx ON public.cash_deposit_allocations USING btree (cashbook_opening_balance_id);


--
-- Name: ledger_heads_code_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ledger_heads_code_uidx ON public.ledger_heads USING btree (code);


--
-- Name: ledger_heads_type_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ledger_heads_type_code_idx ON public.ledger_heads USING btree (type, code);


--
-- Name: parties_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parties_name_idx ON public.parties USING btree (name);


--
-- Name: parties_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parties_status_idx ON public.parties USING btree (status);


--
-- Name: revenue_targets_fy_head_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX revenue_targets_fy_head_uidx ON public.revenue_targets USING btree (financial_year, ledger_head_id);


--
-- Name: shop_collections_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_collections_month_idx ON public.shop_collections USING btree (demand_month);


--
-- Name: shop_collections_shop_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_collections_shop_month_idx ON public.shop_collections USING btree (shop_id, demand_month);


--
-- Name: shop_collections_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_collections_status_idx ON public.shop_collections USING btree (status);


--
-- Name: shops_number_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX shops_number_uidx ON public.shops USING btree (shop_number);


--
-- Name: shops_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shops_status_idx ON public.shops USING btree (status);


--
-- Name: staff_employee_code_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX staff_employee_code_uidx ON public.staff_members USING btree (employee_code);


--
-- Name: staff_payments_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX staff_payments_month_idx ON public.staff_payments USING btree (payment_month);


--
-- Name: staff_payments_staff_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX staff_payments_staff_month_idx ON public.staff_payments USING btree (staff_id, payment_month);


--
-- Name: staff_payments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX staff_payments_status_idx ON public.staff_payments USING btree (status);


--
-- Name: staff_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX staff_status_idx ON public.staff_members USING btree (status);


--
-- Name: tds_fy_quarter_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tds_fy_quarter_idx ON public.tds_returns USING btree (financial_year, quarter);


--
-- Name: tds_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tds_status_idx ON public.tds_returns USING btree (status);


--
-- Name: bills bills_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id);


--
-- Name: bills bills_ledger_head_id_ledger_heads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_ledger_head_id_ledger_heads_id_fk FOREIGN KEY (ledger_head_id) REFERENCES public.ledger_heads(id);


--
-- Name: bills bills_posted_cashbook_entry_id_cashbook_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_posted_cashbook_entry_id_cashbook_entries_id_fk FOREIGN KEY (posted_cashbook_entry_id) REFERENCES public.cashbook_entries(id) ON DELETE SET NULL;


--
-- Name: brs_statements brs_statements_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brs_statements
    ADD CONSTRAINT brs_statements_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id) ON DELETE CASCADE;


--
-- Name: budgets budgets_ledger_head_id_ledger_heads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_ledger_head_id_ledger_heads_id_fk FOREIGN KEY (ledger_head_id) REFERENCES public.ledger_heads(id);


--
-- Name: cash_deposit_allocations cash_deposit_allocations_cash_deposit_id_cash_deposits_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposit_allocations
    ADD CONSTRAINT cash_deposit_allocations_cash_deposit_id_cash_deposits_id_fk FOREIGN KEY (cash_deposit_id) REFERENCES public.cash_deposits(id) ON DELETE CASCADE;


--
-- Name: cash_deposit_allocations cash_deposit_allocations_cashbook_entry_id_cashbook_entries_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposit_allocations
    ADD CONSTRAINT cash_deposit_allocations_cashbook_entry_id_cashbook_entries_id_ FOREIGN KEY (cashbook_entry_id) REFERENCES public.cashbook_entries(id) ON DELETE CASCADE;


--
-- Name: cash_deposit_allocations cash_deposit_allocations_cashbook_opening_balance_id_cashbook_o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposit_allocations
    ADD CONSTRAINT cash_deposit_allocations_cashbook_opening_balance_id_cashbook_o FOREIGN KEY (cashbook_opening_balance_id) REFERENCES public.cashbook_opening_balances(id) ON DELETE CASCADE;


--
-- Name: cash_deposits cash_deposits_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_deposits
    ADD CONSTRAINT cash_deposits_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id);


--
-- Name: cashbook_entries cashbook_entries_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_entries
    ADD CONSTRAINT cashbook_entries_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id);


--
-- Name: cashbook_entries cashbook_entries_ledger_head_id_ledger_heads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashbook_entries
    ADD CONSTRAINT cashbook_entries_ledger_head_id_ledger_heads_id_fk FOREIGN KEY (ledger_head_id) REFERENCES public.ledger_heads(id);


--
-- Name: cheques cheques_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheques
    ADD CONSTRAINT cheques_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id);


--
-- Name: revenue_targets revenue_targets_ledger_head_id_ledger_heads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenue_targets
    ADD CONSTRAINT revenue_targets_ledger_head_id_ledger_heads_id_fk FOREIGN KEY (ledger_head_id) REFERENCES public.ledger_heads(id);


--
-- Name: shop_collections shop_collections_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_collections
    ADD CONSTRAINT shop_collections_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id);


--
-- Name: staff_payments staff_payments_staff_id_staff_members_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_payments
    ADD CONSTRAINT staff_payments_staff_id_staff_members_id_fk FOREIGN KEY (staff_id) REFERENCES public.staff_members(id);


--
-- PostgreSQL database dump complete
--

\unrestrict g7Ol7CXHahjJxlGparhc1A0sFwcCS51CBGg0yaNjyZWtSOtX7jHUadpRXhYy41b

